import React from 'react'
  

function App(){

  return (
    <div >
      <h1> Billing Application</h1>
    </div>
  )
}

export default App